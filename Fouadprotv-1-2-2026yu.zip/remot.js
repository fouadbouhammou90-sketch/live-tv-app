document.addEventListener('keydown', function(e) {
    const focusableElements = document.querySelectorAll('.channel-card, .list-item');
    const focusable = Array.from(focusableElements);
    let index = focusable.indexOf(document.activeElement);

    // حساب عدد الأعمدة في الشبكة (Grid)
    const grid = document.querySelector('.grid-channels');
    const columns = grid ? window.getComputedStyle(grid).getPropertyValue('grid-template-columns').split(' ').length : 1;

    switch(e.key) {
        case 'ArrowRight':
            if (index < focusable.length - 1) focusable[index + 1].focus();
            break;
        case 'ArrowLeft':
            if (index > 0) focusable[index - 1].focus();
            break;
        case 'ArrowDown':
            if (index + columns < focusable.length) focusable[index + columns].focus();
            break;
        case 'ArrowUp':
            if (index - columns >= 0) focusable[index - columns].focus();
            break;
        case 'Enter':
            if (index !== -1) focusable[index].click();
            break;
    }
});

// لجعل أول عنصر محدد تلقائياً عند فتح الصفحة
window.onload = () => {
    const firstItem = document.querySelector('.channel-card, .list-item');
    if (firstItem) firstItem.focus();
};
